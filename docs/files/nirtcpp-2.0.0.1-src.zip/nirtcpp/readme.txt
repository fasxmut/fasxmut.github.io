Nirtcpp Engine
========================================================================

Nirtcpp forks irrlicht Engine 1.9.0. It might fix some old bugs and add new features to the engine.



Nirtcpp 2.0.0
------------------------------------------------------------

Build nirtcpp with sfml rendering backend device:

```
b2 config --prefix=/usr/local --device=sfml
b2 -q -j4
```


Build nirtcpp with default rendering backend device, which is determined by os (windows, x11 or osx):

```
b2 config --prefix=/usr/local
b2 -q -j4
```


B2 build jamfile works for sfml and other backend devices.


Complete implementing sfml backend. (Sep 03, 2023)

* Limit: It's not good to call device->setResizable(); If it is called, it must be called after creating device immediately, and before changing any other resources, and must be not called on the fly. (Sep 03, 2023)


* Start implementing sfml backend. (Jul 31, 2023)
SFML is created as the nirtcpp backend device from nirtcpp 2.0.0. (Jul 31, 2023)

The gui and scene rendering work, and the close event is added currently for sfml backend. The complete sfml backend stack will be added in the future.



requirements (kubuntu)
------------------------------------------------------------

g++

b2 build

pkgconf

libsfml-dev
zlib1g-dev
libpng-dev
libjpeg-dev
libbz2-dev
libxxf86vm-dev



CHANGELOG
-----------------------------------------------------------

Read change.log file.



Development
-----------------------------------------------------------

The nirtcpp development will be made to three stages.

The first stage is to make compatible change and test.

The second stage is to add new features.

The third stage is to do memory safe improvement and test.

And at last the development can do more changes and more things.

Nirtcpp starts from c++20 when forking, that's its minimal c++ standard requirement.



