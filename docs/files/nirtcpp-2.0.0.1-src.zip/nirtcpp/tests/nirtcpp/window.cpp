//
// Copyright (c) 2023 Fas Xmut (fasxmut at protonmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#define BOOST_TEST_MODULE "nirtcpp/window.cpp"
#include <boost/test/unit_test.hpp>
#include <nirtcpp.hpp>
#include <iostream>

BOOST_AUTO_TEST_CASE(test_case_window_01)
{
	std::cout << "--------------------------------------------------------------------------------\n";
	std::cout << "---- test_case_window_01 ----\n";
	nirt::NirtcppDevice * device = nirt::createDevice(
		nirt::video::EDT_OPENGL,
		nirt::core::dimension2du{2560, 1600},
		32,
		false,
		true,
		true,
		nullptr
	);
	BOOST_CHECK_NE(device, nullptr);
	device->setWindowCaption(L"Nirtcpp Window");

	// The window will flick for 4 times.
	std::cout << "The window will flick for 4 times ...\n";
	device->setResizable(true);
	device->setResizable(false);
	device->setResizable(true);
	device->setResizable(false);

	nirt::video::IVideoDriver * driver = device->getVideoDriver();
	nirt::scene::ISceneManager * smgr = device->getSceneManager();

	nirt::ITimer * timer = device->getTimer();

	while (device->run())
	{
		if (device->isWindowActive())
		{
			driver->beginScene(nirt::video::ECBF_COLOR | nirt::video::ECBF_DEPTH, nirt::video::SColor{0xff3474ac});
			smgr->drawAll();
			driver->endScene();
		}
		else
		{
			device->yield();
		}
		if (timer->getTime() > 1)
			device->closeDevice();
	}
	device->drop();
	BOOST_CHECK(true);
}

