//
// Copyright (c) 2023 Fas Xmut (fasxmut at protonmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#define BOOST_TEST_MODULE "nirtcpp/edt-null.cpp"

#include <boost/test/unit_test.hpp>
#include <nirtcpp.hpp>
#include <iostream>

auto print_case_msg = [] (const std::string & case_mark)
{
	std::cout << "--------------------------------------------------------------------------------\n";
	std::cout << "---- " << case_mark << " ----\n\n";
	std::cout << ">>>> If SFML device is used, this test will be used to test nirt::video::EDT_NULL driver on sfml.\n\n";
};

BOOST_AUTO_TEST_CASE(test_case_edt_null_01)
{
	print_case_msg("test_case_edt_null_01");

	nirt::NirtcppDevice * device = nirt::createDevice(
		nirt::video::EDT_NULL,
		nirt::core::dimension2du{2560, 1440},
		32,
		false,
		true,
		true,
		nullptr
	);
	BOOST_CHECK_NE(device, nullptr);
	if (device)
		std::cout << "nirt::video::EDT_NULL: device OK.\n";
	
	nirt::video::IVideoDriver * driver = device->getVideoDriver();
	BOOST_CHECK_NE(driver, nullptr);
	if (driver)
		std::cout << "nirt::video::EDT_NULL: driver OK.\n";

	nirt::scene::ISceneManager * smgr = device->getSceneManager();
	BOOST_CHECK_NE(smgr, nullptr);
	if (smgr)
		std::cout << "nirt::video::EDT_NULL: scene OK.\n";

	nirt::gui::IGUIEnvironment * ngui = device->getGUIEnvironment();
	BOOST_CHECK_NE(ngui, nullptr);
	if (ngui)
		std::cout << "nirt::video::EDT_NULL: gui OK.\n";

	bool status = device->run();
	BOOST_CHECK_EQUAL(status, true);
	if (status)
		std::cout << "nirt::video::EDT_NULL: run OK.\n";

	std::cout << "Running 100 frames to test ...\n";
	nirt::u32 counter = 0;
	bool flag = true;
	while (bool status = device->run())
	{
		driver->beginScene(nirt::video::ECBF_COLOR | nirt::video::ECBF_DEPTH, nirt::video::SColor{0xff327799});
		smgr->drawAll();
		ngui->drawAll();
		if (++counter >= 100)
			device->closeDevice();
		std::cout << counter << ' ';
		flag = flag && status;
		driver->endScene();
	}
	std::cout << std::endl;
	device->drop();
	BOOST_CHECK(flag);
	BOOST_CHECK_EQUAL(counter, 100);
	if (counter == 100)
		std::cout << "BOOST_CHECK_EQUAL(counter, 100) OK.\n";
}

BOOST_AUTO_TEST_CASE(test_case_edt_null_member_functions_01)
{
	print_case_msg("test_case_edt_null_member_functions_01");
	{
		nirt::NirtcppDevice * device = nirt::createDevice(nirt::video::EDT_NULL);
		BOOST_CHECK_NE(device, nullptr);
		if (device)
			std::cout << "nirt::video::EDT_NULL: constructor OK; ->createDriver OK (called by constructor).\n";
		device->setWindowCaption(L"nirt::video::EDT_NULL, no window, no window title");

		// No window, no flick.
		device->setResizable(true);
		device->setResizable(false);
		device->setResizable(true);
		device->setResizable(false);
		
		BOOST_CHECK(true);
		device->setResizable(true);
		device->setResizable(false);
		BOOST_CHECK(true);
		bool status = device->run();
		BOOST_CHECK_EQUAL(status, true);
		if (status)
			std::cout << "->run OK.\n";
		device->drop();
	}
}

