//
// Copyright (c) 2023 Fas Xmut (fasxmut at protonmail dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

// BNirtDeviceSFML.cpp (20230731)

#include <nirtcpp/NirtCompileConfig.hpp>

#ifdef _NIRT_COMPILE_WITH_SFML_DEVICE_

#include "BNirtDeviceSFML.hpp"
#include <nirtcpp/IEventReceiver.hpp>
#include <nirtcpp/irrList.hpp>
#include "os.hpp"
#include "CTimer.hpp"
#include <nirtcpp/irrString.hpp>
#include <nirtcpp/Keycodes.hpp>
#include "COSOperator.hpp"
#include <nirtcpp/SIrrCreationParameters.hpp>
#include <nirtcpp/IGUIEnvironment.hpp>
#include <nirtcpp/ISceneManager.hpp>
#include <nirtcpp/IEventReceiver.hpp>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <chrono>
#include <thread>
#include <vector>
#include <string>

/* // sfml-todo
#ifdef _MSC_VER
#pragma comment(lib, "SFML.lib")
#endif // _MSC_VER
*/

static int sfml_device_instances = 0;

namespace nirt::video
{

#ifdef _NIRT_COMPILE_WITH_OPENGL_
nirt::video::IVideoDriver * createOpenGLDriver(
	const nirt::SNirtcppCreationParameters & params,
	nirt::io::IFileSystem * io, 
	nirt::BNirtDeviceSFML * device
);
#endif

} // namespace nirt::video

// Destructor. sfml-todo
nirt::BNirtDeviceSFML::~BNirtDeviceSFML()
{
	os::Printer::log("Close SFML.", nirt::ELL_INFORMATION);
	/*
	// do not call this:
	this->sfml_window->close();

	If the window is not open, calling it will crash, so we have to check if the window is open or not;
	To check if the window is open or not, we have to check if the pointer (std::unique_ptr) holds a valid
	sf::RenderWindow object or not, otherwise it will crash.

	So the best solution is to destroy the unique pointer directly.
	*/

	if (this->Operator)
	{
		this->Operator->drop();
		this->Operator = nullptr;
	}
	if (this->CursorControl)
	{
		this->CursorControl->drop();
		this->CursorControl = nullptr;
	}
	if (this->GUIEnvironment)
	{
		this->GUIEnvironment->drop();
		this->GUIEnvironment = nullptr;
	}
	if (this->SceneManager)
	{
		this->SceneManager->drop();
		this->SceneManager = nullptr;
	}
	if (this->VideoDriver)
	{
		this->VideoDriver->drop();
		this->VideoDriver = nullptr;
	}
	this->sfml_screen = 0;
	this->sfml_window = nullptr; // Destroy sfml window by std::unique_ptr smart pointer.

	if (--sfml_device_instances == 0)
	{
		os::Printer::log("Last SFML is closed.", nirt::ELL_INFORMATION);
	}

}

// Constructor
nirt::BNirtDeviceSFML::BNirtDeviceSFML(const nirt::SNirtcppCreationParameters & param):
	nirt::CIrrDeviceStub(param),
	sfml_screen{(sf::WindowHandle)(param.WindowId)},
	MouseX{0},
	MouseY{0},
	MouseButtonStates{0},
	Width{param.WindowSize.Width},
	Height{param.WindowSize.Height},
	Resizable{param.WindowResizable==1?true:false},
	WindowMinimized{false}
{
	#ifdef __DEBUG
	this->setDebugName("BNirtDeviceSFML");
	#endif

	++sfml_device_instances;

	nirt::core::stringc sfml_version = "SFML Version ";
	sfml_version += SFML_VERSION_MAJOR;
	sfml_version += ".";
	sfml_version += SFML_VERSION_MINOR;
	sfml_version += ".";
	sfml_version += SFML_VERSION_PATCH;

	this->Operator = new nirt::COSOperator{sfml_version}; // sfml_version is passed as osversion to nirt::COSOperator

	if (sfml_device_instances == 1)
	{
		nirt::os::Printer::log(sfml_version.data(), nirt::ELL_INFORMATION);
	}

	this->init_sfml_style();

	this->createKeyMap();

	if (this->CreationParams.DriverType != nirt::video::EDT_NULL)
	{
		// Real params will be passed to this->sfml_window->create(???)
		this->sfml_window = std::make_unique<sf::RenderWindow>();
		if (! this->createWindow())
			return; // this->createWindow() failed.
		this->setResizable(this->Resizable);
	}
	
	this->CursorControl = new nirt::BNirtDeviceSFML::CCursorControl{
		this,
		this->CreationParams.DriverType == nirt::video::EDT_NULL
	};
	// Set the cursor is visible on window is created.
	this->getCursorControl()->setVisible(true); // this->getCursorControl() aka gets this->CursorControl.
	/*
	Avoid memory address violation:
		"this->getCursorControl()" must be called after "new nirt::BNirtDeviceSFML::CCursorControl",
		"new nirt::BNirtDeviceSFML::CCursorControl" must be called after "createWindow()"
	*/

	this->createDriver(); // including create null driver for EDT_NULL

	if (this->VideoDriver)
	{
		this->createGUIAndScene();
	}
}

// Generate sfml_style by information from this->CreationParams.
void nirt::BNirtDeviceSFML::init_sfml_style()
{
	// sf::Style::Fullscreen flag and all others are mutually exclusive.
	// sf::Style::None flag and all others are mutually exclusive.

	this->sfml_style = sf::Style::Close;
	if (this->CreationParams.Fullscreen)
		this->sfml_style = sf::Style::Fullscreen;
	else
	{
		// CreationParams.WindowResizable: 0, not resdizable; 1: resizable; 2: system decide
		switch (this->CreationParams.WindowResizable)
		{
		case 0: // not resizable
			// do nothing. use default setting: sf::Style::Close (not resizable)
			break;
		case 1: // resizable
			this->sfml_style |= sf::Style::Resize;
			break;
		case 2: // 2 and other values: system decide
		default:
			this->sfml_style |= sf::Style::Default;
			break;
		}
	}
}

// Generate sfml_style by its params, it does not change information of this->CreationParams.
void nirt::BNirtDeviceSFML::update_sfml_style(bool new_resizable)
{
	// sf::Style::Fullscreen flag and all others are mutually exclusive.
	// sf::Style::None flag and all others are mutually exclusive.
	this->sfml_style = sf::Style::Close;
	if (this->CreationParams.Fullscreen)
		this->sfml_style = sf::Style::Fullscreen;
	else if (new_resizable)
		this->sfml_style |= sf::Style::Resize;

	//else
	//		do nothing. use default setting: sf::Style::Close (not resizable)
}

// sfml-todo: need test, and implement null driver, soft driver, burningsvideo driver.
bool nirt::BNirtDeviceSFML::createWindow()
{
	//if (this->Close)
		//return false;

// Only SFML OpenGL Window is supported currently

	switch (this->CreationParams.DriverType)
	{
	case nirt::video::EDT_OPENGL:
		return this->createSFMLGLWindow();
	default:
		return false;
	}
	return false;
}

// If the driver is EDT_OPENGL, createWindow will call this method.
bool nirt::BNirtDeviceSFML::createSFMLGLWindow()
{

// Try create sfml window.
	if (! this->sfml_window->isOpen())
	{
		this->create_sfml_gl_window_proxy();
		if (this->sfml_window->isOpen())
		{
			this->on_create_sfml_gl_window();
			return true;
		}
		// else
		while (this->CreationParams.AntiAlias > 1)
		{
			this->create_sfml_gl_window_proxy();
			if (this->sfml_window->isOpen())
			{
				this->on_create_sfml_gl_window();
				return true;
			}
			(this->CreationParams.AntiAlias)--;
		}
	}
	else
	{
		return true; // sfml-todo. // Previous uncleaned opened window ?
	}

	return false;
}

// short hand of sfml_window->create(???)
// This method only do sfml_window->create, and does not do any checks.
void nirt::BNirtDeviceSFML::create_sfml_gl_window_proxy()
{
// bitsPerPixel:
//		the third param of sf::VideoMode,
//		and the nirt::SNirtcppCreationParameters::Bits.
//	Only useful in fullscreen mode. (???)
//	value: 32, 24, ...
	this->sfml_window->create(
		sf::VideoMode{this->Width, this->Height, this->CreationParams.Bits},
		"",
		this->sfml_style,
		sf::ContextSettings{
			this->CreationParams.ZBufferBits,  // Depth Buffer Bits
			this->CreationParams.Stencilbuffer ? 8u : 0u,
			this->CreationParams.AntiAlias, // Anti Alias Level
			3,	// GL Major Version - Use default
			3,	// GL Minor Version - Use default
			sf::ContextSettings::Attribute::Default, // attributes,	// Default, Core, Debug - Use default
			this->CreationParams.HandleSRGB // srgb	// use default false
		}
	);
}

// If create_sfml_gl_window_proxy() is called, and sfml_window->isOpen() returns true, call this method.
// It does not do any checks.
void nirt::BNirtDeviceSFML::on_create_sfml_gl_window()
{
	nirt::core::position2di & pos = this->CreationParams.WindowPosition;
	this->sfml_window->setPosition(sf::Vector2i{pos.X, pos.Y});
	
	this->sfml_window->setVerticalSyncEnabled(this->CreationParams.Vsync);
	this->sfml_window->setFramerateLimit(60); // sfml-todo: make more detailed control.
	this->sfml_window->setKeyRepeatEnabled(true);
	this->sfml_window->setVisible(true);
	this->sfml_window->setActive(true);
	this->sfml_screen = this->sfml_window->getSystemHandle();
}

// sfml-finished: Create Video Driver.
void nirt::BNirtDeviceSFML::createDriver()
{
	switch (this->CreationParams.DriverType)
	{
	case nirt::video::EDT_OPENGL:
		#ifdef _NIRT_COMPILE_WITH_OPENGL_
		this->VideoDriver = nirt::video::createOpenGLDriver(this->CreationParams, this->FileSystem, this);
		#else
		os::Printer::log("No OpenGL compiled in.", nirt::ELL_ERROR);
		#endif
		break;
	case nirt::video::EDT_NULL:
		this->VideoDriver = nirt::video::createNullDriver(this->FileSystem, this->CreationParams.WindowSize);
		break;
	default:
		os::Printer::log("No Such Video Driver is created for SFML.", nirt::ELL_ERROR);
		break;
	}
}

bool nirt::BNirtDeviceSFML::run()
{
	nirt::os::Timer::tick();

	if (this->CreationParams.DriverType == nirt::video::EDT_NULL)
		return ! this->Close; // Do not change this->Close value here, but return it, as the null driver must do its loop.

	// else .if

	if (! this->sfml_window->isOpen())
	{
		this->Close = true; // Set this->Close value to true, as the gl driver window is closed.
		return false;
	}

	// else

	nirt::SEvent nirt_event;
	sf::Event sfml_event;
	while (this->sfml_window->pollEvent(sfml_event))
	{
		switch (sfml_event.type)
		{
		case sf::Event::KeyPressed:
		case sf::Event::KeyReleased:
		{
			nirt::EKEY_CODE key_code;
			if (KeyMap.contains(sfml_event.key.code))
				key_code = KeyMap[sfml_event.key.code];
			else
				key_code = nirt::EKEY_CODE(0);

			#ifdef _NIRT_WINDOWS_API_
			// sfml-todo
			// if windows-key-Alt-F4, 
			//	this->Close = true;
			//	break;
			#endif

			nirt_event.EventType = nirt::EET_KEY_INPUT_EVENT;
			nirt_event.KeyInput.Key = key_code;
			nirt_event.KeyInput.PressedDown = (sfml_event.type == sf::Event::KeyPressed);
			nirt_event.KeyInput.Control = sfml_event.key.control; // bool, in SFML/Window/Event.hpp
			nirt_event.KeyInput.Shift = sfml_event.key.shift; // bool, in SFML/Window/Event.hpp
			nirt_event.KeyInput.Char = sfml_event.text.unicode; // wchar_t <- sf::Uint32
			this->postEventFromUser(nirt_event);
			break;
		} // case sf::Event::KeyPressed: case sf::Event::KeyReleased:
		case sf::Event::MouseMoved:
			nirt_event.EventType = nirt::EET_MOUSE_INPUT_EVENT;
			nirt_event.MouseInput.Event = nirt::EMIE_MOUSE_MOVED;
			this->MouseX = nirt_event.MouseInput.X = sfml_event.mouseMove.x;
			this->MouseY = nirt_event.MouseInput.Y = sfml_event.mouseMove.y;
			nirt_event.MouseInput.ButtonStates = this->MouseButtonStates;
			this->postEventFromUser(nirt_event);
			break;
		case sf::Event::MouseButtonPressed:
		case sf::Event::MouseButtonReleased:
		case sf::Event::MouseWheelScrolled:
		case sf::Event::MouseEntered: // sfml-todo: No implementation: Mouse curor enters window.
		case sf::Event::MouseLeft: // sfml-todo: No implementation: Mouse curor leaves window.
			nirt_event.EventType = nirt::EET_MOUSE_INPUT_EVENT;
			nirt_event.MouseInput.X = sfml_event.mouseMove.x;
			nirt_event.MouseInput.Y = sfml_event.mouseMove.y;
			nirt_event.MouseInput.Event = nirt::EMIE_MOUSE_MOVED;
			switch (sfml_event.mouseButton.button)
			{
			case sf::Mouse::Left:
				// do not switch if and else !!!
				if (sfml_event.type == sf::Event::MouseButtonPressed)
				{
					nirt_event.MouseInput.Event = nirt::EMIE_LMOUSE_PRESSED_DOWN;
					this->MouseButtonStates |= nirt::EMBSM_LEFT;
				}
				else
				{
					nirt_event.MouseInput.Event = nirt::EMIE_LMOUSE_LEFT_UP;
					this->MouseButtonStates &= !nirt::EMBSM_LEFT;
				}
				break;
			case sf::Mouse::Right:
				// do not switch if and else !!!
				if (sfml_event.type == sf::Event::MouseButtonPressed)
				{
					nirt_event.MouseInput.Event = nirt::EMIE_RMOUSE_PRESSED_DOWN;
					this->MouseButtonStates |= nirt::EMBSM_RIGHT;
				}
				else
				{
					nirt_event.MouseInput.Event = nirt::EMIE_RMOUSE_LEFT_UP;
					this->MouseButtonStates &= ~nirt::EMBSM_RIGHT;
				}
				break;
			case sf::Mouse::Middle:
				// do not switch if and else !!!
				if (sfml_event.type == sf::Event::MouseButtonPressed)
				{
					nirt_event.MouseInput.Event = nirt::EMIE_MMOUSE_PRESSED_DOWN;
					this->MouseButtonStates |= nirt::EMBSM_MIDDLE;
				}
				else
				{
					nirt_event.MouseInput.Event = nirt::EMIE_MMOUSE_LEFT_UP;
					this->MouseButtonStates &= ~nirt::EMBSM_MIDDLE;
				}
				break;
			default:
				break;
			} // switch (sfml_event.mouseButton.button)
			if (sfml_event.type == sf::Event::MouseWheelScrolled)
			{
				/* sfml-todo: not need this block or do something ...

				if (sfml_event.mouseWheelScroll.wheel == sf::Mouse::VerticalWheel)
				{
				}
				else if (sfml_event.mouseWheelScroll.wheel == sf::Mouse::HorizontalWheel)
				{
					// sfml-todo: no implementation
				}
				else
				{
					// sfml-todo: no implementation
				}

				*/

				nirt_event.MouseInput.Event = nirt::EMIE_MOUSE_WHEEL;
				nirt_event.MouseInput.Wheel = sfml_event.mouseWheelScroll.delta; // 1.0f: Up; -1.0f: Down.
			}
			// sfml-todo: clear ButtonStates ?
			nirt_event.MouseInput.ButtonStates = this->MouseButtonStates;

			if (nirt_event.MouseInput.Event != nirt::EMIE_MOUSE_MOVED) // exclusive
			{
				this->postEventFromUser(nirt_event);
				if (nirt_event.MouseInput.Event >= nirt::EMIE_LMOUSE_PRESSED_DOWN
					&& nirt_event.MouseInput.Event <= nirt::EMIE_MMOUSE_PRESSED_DOWN)
				{
					nirt::u32 clicks = this->checkSuccessiveClicks(
						nirt_event.MouseInput.X, nirt_event.MouseInput.Y, nirt_event.MouseInput.Event);
					if (clicks == 2)
					{
						nirt_event.MouseInput.Event = (nirt::EMOUSE_INPUT_EVENT)(
							nirt::EMIE_LMOUSE_DOUBLE_CLICK
								+ nirt_event.MouseInput.Event 
								- nirt::EMIE_LMOUSE_PRESSED_DOWN
						);
						this->postEventFromUser(nirt_event);
					}
					else if (clicks == 3)
					{
						nirt_event.MouseInput.Event = (nirt::EMOUSE_INPUT_EVENT)(
							nirt::EMIE_LMOUSE_TRIPLE_CLICK 
								+ nirt_event.MouseInput.Event
								- nirt::EMIE_LMOUSE_PRESSED_DOWN
						);
						this->postEventFromUser(nirt_event);
					}
				}
			}
			break; // case, mouse button event.
		case sf::Event::Closed:
			this->Close = true;
			break;
		case sf::Event::Resized:
			if (this->Width != sfml_event.size.width || this->Height != sfml_event.size.height)
			{
				this->Width = sfml_event.size.width;
				this->Height = sfml_event.size.height;
				// sfml-todo: might not need resize sfml view
				// resize_sfml_view();
				if (this->VideoDriver)
					this->VideoDriver->OnResize(nirt::core::dimension2du{this->Width, this->Height});
			}
			break;
		case sf::Event::GainedFocus: // used to change sfml_window_focused value.
			this->sfml_window_focused = true;
			this->WindowMinimized = false;
			break;
		case sf::Event::LostFocus: // used to change sfml_window_focused value.
			this->sfml_window_focused = false;
			break;
		// case user_event:		// sfml-todo: no sfml user event
		default:
			break;
		} // switch (sfml_event.type)
	} // while

#if defined(_NIRT_COMPILE_WITH_JOYSTICK_EVENTS_)
	// sfml-todo: jostick event
#endif

	return ! this->Close;
} // run

// sfml-todo: more accurate keys
void nirt::BNirtDeviceSFML::createKeyMap()
{
/*
// not exists sfml key codes:
clear
capslk
print
help
power or sleep
separator
numlock
scrolllock
*/
	this->KeyMap = {
		{sf::Keyboard::Backspace, nirt::KEY_BACK},
		{sf::Keyboard::Enter, nirt::KEY_RETURN},
		{sf::Keyboard::Tab, nirt::KEY_TAB},

		{sf::Keyboard::Pause, nirt::KEY_PAUSE},
		{sf::Keyboard::Escape, nirt::KEY_ESCAPE},
		{sf::Keyboard::Space, nirt::KEY_SPACE},
		{sf::Keyboard::PageUp, nirt::KEY_PRIOR},
		{sf::Keyboard::PageDown, nirt::KEY_NEXT},

		{sf::Keyboard::End, nirt::KEY_END},
		{sf::Keyboard::Home, nirt::KEY_HOME},

		{sf::Keyboard::Left, nirt::KEY_LEFT},
		{sf::Keyboard::Right, nirt::KEY_RIGHT},
		{sf::Keyboard::Up, nirt::KEY_UP},
		{sf::Keyboard::Down, nirt::KEY_DOWN},

		{sf::Keyboard::Insert, nirt::KEY_INSERT},
		{sf::Keyboard::Delete, nirt::KEY_DELETE},

		{sf::Keyboard::LSystem, nirt::KEY_LWIN},
		{sf::Keyboard::RSystem, nirt::KEY_RWIN},

		{sf::Keyboard::Add, nirt::KEY_ADD}, // +
		{sf::Keyboard::Subtract, nirt::KEY_SUBTRACT}, // -
		{sf::Keyboard::Multiply, nirt::KEY_MULTIPLY}, // *
		{sf::Keyboard::Slash, nirt::KEY_DIVIDE}, // /
		{sf::Keyboard::Period, nirt::KEY_PERIOD}, // .
		{sf::Keyboard::Comma, nirt::KEY_COMMA}, // ,

		{sf::Keyboard::LControl, nirt::KEY_LCONTROL},
		{sf::Keyboard::RControl, nirt::KEY_RCONTROL},

		{sf::Keyboard::LShift, nirt::KEY_LSHIFT},
		{sf::Keyboard::RShift, nirt::KEY_RSHIFT},

		{sf::Keyboard::LAlt, nirt::KEY_LMENU},
		{sf::Keyboard::RAlt, nirt::KEY_RMENU},

		{sf::Keyboard::Num0, nirt::KEY_KEY_0},
		{sf::Keyboard::Num1, nirt::KEY_KEY_1},
		{sf::Keyboard::Num2, nirt::KEY_KEY_2},
		{sf::Keyboard::Num3, nirt::KEY_KEY_3},
		{sf::Keyboard::Num4, nirt::KEY_KEY_4},
		{sf::Keyboard::Num5, nirt::KEY_KEY_5},
		{sf::Keyboard::Num6, nirt::KEY_KEY_6},
		{sf::Keyboard::Num7, nirt::KEY_KEY_7},
		{sf::Keyboard::Num8, nirt::KEY_KEY_8},
		{sf::Keyboard::Num9, nirt::KEY_KEY_9},

		{sf::Keyboard::A, nirt::KEY_KEY_A},
		{sf::Keyboard::B, nirt::KEY_KEY_B},
		{sf::Keyboard::C, nirt::KEY_KEY_C},
		{sf::Keyboard::D, nirt::KEY_KEY_D},
		{sf::Keyboard::E, nirt::KEY_KEY_E},
		{sf::Keyboard::F, nirt::KEY_KEY_F},
		{sf::Keyboard::G, nirt::KEY_KEY_G},
		{sf::Keyboard::H, nirt::KEY_KEY_H},
		{sf::Keyboard::I, nirt::KEY_KEY_I},
		{sf::Keyboard::J, nirt::KEY_KEY_J},
		{sf::Keyboard::K, nirt::KEY_KEY_K},
		{sf::Keyboard::L, nirt::KEY_KEY_L},
		{sf::Keyboard::M, nirt::KEY_KEY_M},
		{sf::Keyboard::N, nirt::KEY_KEY_N},
		{sf::Keyboard::O, nirt::KEY_KEY_O},
		{sf::Keyboard::P, nirt::KEY_KEY_P},
		{sf::Keyboard::Q, nirt::KEY_KEY_Q},
		{sf::Keyboard::R, nirt::KEY_KEY_R},
		{sf::Keyboard::S, nirt::KEY_KEY_S},
		{sf::Keyboard::T, nirt::KEY_KEY_T},
		{sf::Keyboard::U, nirt::KEY_KEY_U},
		{sf::Keyboard::V, nirt::KEY_KEY_V},
		{sf::Keyboard::W, nirt::KEY_KEY_W},
		{sf::Keyboard::X, nirt::KEY_KEY_X},
		{sf::Keyboard::Y, nirt::KEY_KEY_Y},
		{sf::Keyboard::Z, nirt::KEY_KEY_Z},

		{sf::Keyboard::F1, nirt::KEY_F1},
		{sf::Keyboard::F2, nirt::KEY_F2},
		{sf::Keyboard::F3, nirt::KEY_F3},
		{sf::Keyboard::F4, nirt::KEY_F4},
		{sf::Keyboard::F5, nirt::KEY_F5},
		{sf::Keyboard::F6, nirt::KEY_F6},
		{sf::Keyboard::F7, nirt::KEY_F7},
		{sf::Keyboard::F8, nirt::KEY_F8},
		{sf::Keyboard::F9, nirt::KEY_F9},
		{sf::Keyboard::F10, nirt::KEY_F10},
		{sf::Keyboard::F11, nirt::KEY_F11},
		{sf::Keyboard::F12, nirt::KEY_F12},
		{sf::Keyboard::F13, nirt::KEY_F13},
		{sf::Keyboard::F14, nirt::KEY_F14},
		{sf::Keyboard::F15, nirt::KEY_F15},

		{sf::Keyboard::Numpad0, nirt::KEY_NUMPAD0},
		{sf::Keyboard::Numpad1, nirt::KEY_NUMPAD1},
		{sf::Keyboard::Numpad2, nirt::KEY_NUMPAD2},
		{sf::Keyboard::Numpad3, nirt::KEY_NUMPAD3},
		{sf::Keyboard::Numpad4, nirt::KEY_NUMPAD4},
		{sf::Keyboard::Numpad5, nirt::KEY_NUMPAD5},
		{sf::Keyboard::Numpad6, nirt::KEY_NUMPAD6},
		{sf::Keyboard::Numpad7, nirt::KEY_NUMPAD7},
		{sf::Keyboard::Numpad8, nirt::KEY_NUMPAD8},
		{sf::Keyboard::Numpad9, nirt::KEY_NUMPAD9}
	};
}

// sfml-todo
void nirt::BNirtDeviceSFML::yield()
{
	std::this_thread::sleep_for(std::chrono::milliseconds(80));
}

// sfml-todo: use std::this_thread::sleep_for ?
void nirt::BNirtDeviceSFML::sleep(nirt::u32 time_ms, bool pause_timer)
{
	const bool was_stopped = this->Timer ? this->Timer->isStopped() : true;
	if (pause_timer && ! was_stopped)
		this->Timer->stop();
	std::this_thread::sleep_for(std::chrono::milliseconds(time_ms));
	if (pause_timer && ! was_stopped)
		this->Timer->start();
}

// sfml-finished
void nirt::BNirtDeviceSFML::closeDevice()
{
	this->Close = true;
}

// This is identically calling SFML window display
void nirt::BNirtDeviceSFML::sfml_display()
{
	this->sfml_window->display();
}

// sfml-todo
nirt::video::ECOLOR_FORMAT nirt::BNirtDeviceSFML::getColorFormat() const
{
	if (! this->sfml_window->isOpen())
		return nirt::CIrrDeviceStub::getColorFormat();
	
	// else if

	if (this->sfml_window->getSettings().depthBits == 32)
		return nirt::video::ECF_A8R8G8B8;
	
	// else

	// sfml-todo: better getColorFormat

	return nirt::video::ECF_R8G8B8;
}

// sfml-todo
void nirt::BNirtDeviceSFML::setWindowCaption(const wchar_t * text)
{
	if (this->CreationParams.DriverType == nirt::video::EDT_NULL)
		return;
	sf::String title_text{text};
	this->sfml_window->setTitle(title_text);
}

// sfml-todo: need test
// this->present(??) is used for EDT_SOFTWARE and EDT_BURNINGSVIDEO
bool nirt::BNirtDeviceSFML::present(
	nirt::video::IImage * src_surface, 
	void * dst_window_id,
	nirt::core::rect<s32> * src_clip
)
{
	if (! this->SoftwareImage)
		return true;
	nirt::u32 src_width = src_surface->getDimension().Width;
	nirt::u32 src_height = src_surface->getDimension().Height;
	auto * src_data = new std::vector<nirt::u8>;
	for (nirt::u32 j=0; j<src_height; j++)
	{
		for (nirt::u32 i=0; i<src_width; i++)
		{
			nirt::video::SColor col = src_surface->getPixel(i, j);
			src_data->push_back(col.getRed());
			src_data->push_back(col.getGreen());
			src_data->push_back(col.getBlue());
			src_data->push_back(col.getAlpha());
		}
	}
	if (src_data->empty())
	{
		delete src_data;
		return false;
	}
	auto * src_image = new sf::Image;
	src_image->create(src_width, src_height, src_data->data()); // unsigned 8bit bit pointer
	delete src_data;
	auto * src_texture = new sf::Texture;
	bool status = false;
	if (src_clip)
	{
		// set int here. Other integral type is not tested.
		sf::Rect<int> rect{src_clip->UpperLeftCorner.X, src_clip->UpperLeftCorner.Y,
			src_clip->getWidth(), src_clip->getHeight()};
		status = src_texture->loadFromImage(*src_image, rect);
	}
	else
	{
		status = src_texture->loadFromImage(*src_image);
	}
	delete src_image;
	if (! status)
	{
		delete src_texture;
		return false;
	}
	auto * src_sprite = new sf::Sprite{*src_texture};

	sf::RenderWindow dst_window;
	dst_window.create((sf::WindowHandle)dst_window_id);
	if (dst_window.isOpen())
	{
		dst_window.draw(* src_sprite);
		delete src_sprite;
		delete src_texture;
		return true;
	}

	// same as else if follows above.
	if (this->sfml_window->isOpen())
	{
		this->sfml_window->draw(* src_sprite);
		delete src_sprite;
		delete src_texture;
		return true;
	}

		// same as else if follows above.

	delete src_sprite;
	delete src_texture;
	return false;
}

bool nirt::BNirtDeviceSFML::isWindowActive() const
{
	// check sfml_window_focused, not check sfml_window.isOpen(), otherwise null device will crash.
	return this->sfml_window_focused;
}

bool nirt::BNirtDeviceSFML::isWindowFocused() const
{
	return this->sfml_window_focused;
}

bool nirt::BNirtDeviceSFML::isWindowMinimized() const
{
	return this->WindowMinimized;
}

// sfml-todo
void nirt::BNirtDeviceSFML::restoreWindow()
{
}

nirt::core::position2di nirt::BNirtDeviceSFML::getWindowPosition()
{
	sf::Vector2i pos = this->sfml_window->getPosition();
	return nirt::core::position2di{pos.x, pos.y};
}

// This is knavery
void nirt::BNirtDeviceSFML::maximizeWindow()
{
}

// This is knavery
void nirt::BNirtDeviceSFML::minimizeWindow()
{
}

// sfml-todo
nirt::video::IVideoModeList * nirt::BNirtDeviceSFML::getVideoModeList()
{
	if (this->VideoModeList->getVideoModeCount() <= 0)
	{
		for (const sf::VideoMode & mode: sf::VideoMode::getFullscreenModes())
		{
			if (mode.isValid())
			{
				this->VideoModeList->addMode(nirt::core::dimension2du{mode.width, mode.height}, mode.bitsPerPixel);
			}
		}
	}
	nirt::core::stringc str_log = "Total available video modes: ";
	str_log += this->VideoModeList->getVideoModeCount();
	os::Printer::log(str_log.data(), nirt::ELL_INFORMATION);
	return this->VideoModeList;
}

// Limit: setResizable(?)  must be called before drawing, adding scene/gui objects.
void nirt::BNirtDeviceSFML::setResizable(bool new_resizable)
{
	/*
	It's not good to call device->setResizable(); If it is called, it must be called after creating device immediately, and before changing any other resources, and must be not called on the fly.
	*/
	std::string log_msg = "NOTICE: device->setResizable() is called!";

	if (
		new_resizable == this->Resizable
		|| this->CreationParams.DriverType == nirt::video::EDT_NULL
		|| this->CreationParams.Fullscreen
	) // do nothing, and do not flick screen more once
	{
		log_msg += " - do nothing, no change.";
		os::Printer::log(log_msg.data(), nirt::ELL_INFORMATION);
		return;
	}

	// else

	this->update_sfml_style(new_resizable);
	this->create_sfml_gl_window_proxy(); // It will flick screen more once, if the window is already created.
	if (this->sfml_window->isOpen())
	{
		log_msg += " - has open window, window is recreated and flicked.";
		this->on_create_sfml_gl_window();
	}
	else
	{
		log_msg += "- no open window, no flick.";
	}
	this->Resizable = new_resizable;
	os::Printer::log(log_msg.data(), nirt::ELL_INFORMATION);
}

// sfml-todo
bool nirt::BNirtDeviceSFML::setGammaRamp(nirt::f32 red, nirt::f32 green, nirt::f32 blue, nirt::f32 brightness, nirt::f32 contrast)
{
	return false;
}

// sfml-todo
bool nirt::BNirtDeviceSFML::getGammaRamp(nirt::f32 &red, nirt::f32 &green, nirt::f32 & blue, nirt::f32 & brightness, nirt::f32 & contrast)
{
	return false;
}


// sfml-todo
bool nirt::BNirtDeviceSFML::activateJoysticks(nirt::core::array<nirt::SJoystickInfo> & joystick_info)
{
	return false;
}

#endif // _NIRT_COMPILE_WITH_SFML_DEVICE_

