// Copyright (C) 2009-2012 Gary Conway
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in nirtcpp/nirtcpp.hpp


/*
	Author:	Gary Conway (Viper) - co-author of the ZIP file format, Feb 1989,
						see the story at http://www.idcnet.us/ziphistory.html
	Website:	http://idcnet.us
	Email:		codeslinger@vipergc.com
	Created:	March 1, 2009
	Version:	1.0
	Updated:
*/

#ifndef NIRT_C_IMAGE_LOADER_RGB_HPP_INCLUDED
#define NIRT_C_IMAGE_LOADER_RGB_HPP_INCLUDED

// define _NIRT_RGB_FILE_INVERTED_IMAGE_ to preserve the inverted format of the RGB file
// commenting this out will invert the inverted image,resulting in the image being upright
#define _NIRT_RGB_FILE_INVERTED_IMAGE_

#include <nirtcpp/NirtCompileConfig.hpp>

#ifdef _NIRT_COMPILE_WITH_RGB_LOADER_

#include <nirtcpp/IImageLoader.hpp>

namespace nirt
{
namespace video
{

// byte-align structures
#include <nirtcpp/irrpack.hpp>

	// the RGB image file header structure

	struct SRGBHeader
	{
		u16 Magic;	// IRIS image file magic number
		u8  Storage;	// Storage format
		u8  BPC;	// Number of bytes per pixel channel
		u16 Dimension;	// Number of dimensions
		u16 Xsize;	// X size in pixels
		u16 Ysize;	// Y size in pixels
		u16 Zsize;	// Z size in pixels
		u32 Pixmin;	// Minimum pixel value
		u32 Pixmax;	// Maximum pixel value
		u32 Dummy1;	// ignored
		char Imagename[80];// Image name
		u32 Colormap;	// Colormap ID
//		char Dummy2[404];// Ignored
	} PACK_STRUCT;

// Default alignment
#include <nirtcpp/irrunpack.hpp>

	// this structure holds context specific data about the file being loaded.

	using rgbStruct = struct _RGBdata
	{
		u8 *tmp;
		u8 *tmpR;
		u8 *tmpG;
		u8 *tmpB;
		u8 *tmpA;

		u32 *StartTable;	// compressed data table, holds file offsets
		u32 *LengthTable;	// length for the above data, hold lengths for above
		u32 TableLen;		// len of above tables

		SRGBHeader Header;	// define the .rgb file header
		u32 ImageSize;
		u8 *rgbData;

	public:
		_RGBdata() : tmp(0), tmpR(0), tmpG(0), tmpB(0), tmpA(0),
			StartTable(0), LengthTable(0), TableLen(0), ImageSize(0), rgbData(0)
		{
		}

		~_RGBdata()
		{
			delete [] tmp;
			delete [] tmpR;
			delete [] tmpG;
			delete [] tmpB;
			delete [] tmpA;
			delete [] StartTable;
			delete [] LengthTable;
			delete [] rgbData;
		}

		bool allocateTemps()
		{
			tmp = tmpR = tmpG = tmpB = tmpA = 0;
			tmp = new u8 [Header.Xsize * 256 * Header.BPC];
			if (!tmp)
				return false;

			if (Header.Zsize >= 1)
			{
				tmpR = new u8[Header.Xsize * Header.BPC];
				if (!tmpR)
					return false;
			}
			if (Header.Zsize >= 2)
			{
				tmpG = new u8[Header.Xsize * Header.BPC];
				if (!tmpG)
					return false;
			}
			if (Header.Zsize >= 3)
			{
				tmpB = new u8[Header.Xsize * Header.BPC];
				if (!tmpB)
					return false;
			}
			if (Header.Zsize >= 4)
			{
				tmpA = new u8[Header.Xsize * Header.BPC];
				if (!tmpA)
					return false;
			}
			return true;
		}
	};


//! Surface Loader for Silicon Graphics RGB files
class CImageLoaderRGB : public IImageLoader
{
public:

	//! constructor
	CImageLoaderRGB();

	//! returns true if the file maybe is able to be loaded by this class
	//! based on the file extension (e.g. ".tga")
	virtual bool isALoadableFileExtension(const io::path& filename) const override;

	//! returns true if the file maybe is able to be loaded by this class
	virtual bool isALoadableFileFormat(io::IReadFile* file) const override;

	//! creates a surface from the file
	virtual IImage* loadImage(io::IReadFile* file) const override;

private:

	bool readHeader(io::IReadFile* file, rgbStruct& rgb) const;
	void readRGBrow(u8 *buf, int y, int z, io::IReadFile* file, rgbStruct& rgb) const;
	void processFile(io::IReadFile *file, rgbStruct& rgb) const;
	bool checkFormat(io::IReadFile *file, rgbStruct& rgb) const;
	bool readOffsetTables(io::IReadFile* file, rgbStruct& rgb) const;
	void converttoARGB(u32* in, const u32 size) const;
};

} // end namespace video
} // end namespace nirt

#endif // _NIRT_COMPILE_WITH_RGB_LOADER_
#endif // NIRT_C_IMAGE_LOADER_RGB_HPP_INCLUDED
