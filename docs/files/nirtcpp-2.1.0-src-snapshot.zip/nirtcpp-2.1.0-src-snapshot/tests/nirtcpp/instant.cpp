#if __has_include ("./instant.hpp")
#include "./instant.hpp"
#else
int main()
{
}
#endif

