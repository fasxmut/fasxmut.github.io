
#ifndef _TEST_UTILS_H_
#define _TEST_UTILS_H_ 1

#include <nirtcpp/nirtcpp.hpp>
#include <assert.h>

// Small hack. Some newer X11 systems can't handle switching drivers too fast (causing BadWindow errors in X_ChangeWindowAttributes).
// Could be they don't like when Windows with different Visuals are created very quickly (it always happened after creating a new Window with different Visual to previous one).
// timeMs value set by try&error
#ifdef _NIRT_POSIX_API_
	#include <time.h>
	#define SLOW_SWITCH \
	do { \
		struct timespec ts; \
		const int timeMs = 250; \
		ts.tv_sec = (time_t) (timeMs / 1000); \
		ts.tv_nsec = (long) (timeMs % 1000) * 1000000; \
		nanosleep(&ts, NULL);\
	} while (false)
#else
	#define SLOW_SWITCH
#endif

#define TestWithAllDrivers(X) \
	logTestString("Running test " #X "\n"); \
	for (u32 i=1; i<video::EDT_COUNT; ++i) \
		if (video::E_DRIVER_TYPE(i) != video::DEPRECATED_EDT_DIRECT3D8_NO_LONGER_EXISTS && nirt::NirtcppDevice::isDriverSupported((nirt::video::E_DRIVER_TYPE)i)) \
		{\
			SLOW_SWITCH; \
			result &= X(video::E_DRIVER_TYPE(i));\
		}

#define TestWithAllHWDrivers(X) \
	SLOW_SWITCH; \
	logTestString("Running test " #X "\n"); \
	for (u32 i=video::EDT_DIRECT3D9; i<video::EDT_COUNT; ++i) \
		if (nirt::NirtcppDevice::isDriverSupported((nirt::video::E_DRIVER_TYPE)i)) \
		{\
			SLOW_SWITCH; \
			result &= X(video::E_DRIVER_TYPE(i));\
		}

// replacement for assert which does log the lines instead
#define assert_log(X) \
do { \
	if ( !(X) ) \
	{ \
		logTestString("ASSERT in %s:%d: %s\n", __FILE__, __LINE__, #X); \
	} \
} while (false)

//! Compare two files
/** \param fileName1 The first file for comparison.
	\param fileName2 The second file for comparison.
	\return true if the files are identical, false on any error or difference. */
extern bool binaryCompareFiles(const char * fileName1, const char * fileName2);

//! Compare two xml-files (which can have different types of text-encoding)
/** \param fs Filesystem which should be used.
	\param fileName1 The first file for comparison.
	\param fileName2 The second file for comparison.
	\return true if the files are identical, false on any error or difference. */
extern bool xmlCompareFiles(nirt::io::IFileSystem * fs, const char * fileName1, const char * fileName2);

//! Compare two images, returning the degree to which they match.
/** \param driver The Nirtcpp video driver.
	\param fileName1 The first image to compare.
	\param fileName2 The second image to compare.
	\return The match, from 0.f to 100.f */
extern float fuzzyCompareImages(nirt::video::IVideoDriver * driver,
		const char * fileName1, const char * fileName2);

//! Take a screenshot and compare it against a reference screenshot in the tests/media subdirectory
/** \param driver The Nirtcpp video driver.
	\param fileName The unique filename suffix that will be appended to the name of the video driver.
	\param requiredMatch The degree to which the screenshot needs to match the reference image
	in order to be considered a match.
	\return true if the screenshot was taken and is identical to the reference image of the same name
	in the tests/media directory, false on any error or difference. */
extern bool takeScreenshotAndCompareAgainstReference(nirt::video::IVideoDriver * driver,
													const char * fileName,
													nirt::f32 requiredMatch = 99.f);

//! Stabilize the screen background eg. eliminate problems like an aero transparency effects etc.
/** \param driver The Nirtcpp video driver.
	\return true if required color is the same as a window background color. */
extern void stabilizeScreenBackground(nirt::video::IVideoDriver * driver,
													nirt::video::SColor color = nirt::video::SColor(255, 255, 255, 255));


//! Opens a test log file, deleting any existing contents.
/** \param startNewLog true to create a new log file, false to append to an
						existing one.
	\param filename The filename to open
	\return true if the test log file was opened, false on error. */
extern bool openTestLog(bool startNewLog, const char * filename = "tests.log");

//! Close the test log file opened with openTestLog()
extern void closeTestLog();

//! Log a string to the console and the test log file created by openTestLog().
/** \param format The format string
	\... optional parameters */
extern void logTestString(const char * format, ...);

//! Return a drivername for the driver which is useable in filenames
extern nirt::core::stringc shortDriverName(nirt::video::IVideoDriver * driver);

#endif // _TEST_UTILS_H_
