#include <nirtcpp/core.hpp>
#include <string>
#include <iostream>
#include <filesystem>

namespace video = nirt::video;
namespace scene = nirt::scene;
namespace core = nirt::core;
namespace io = nirt::io;
namespace fs = std::filesystem;
namespace gui = nirt::gui;
using namespace std::string_literals;

int main()
try
{
	nirt::NirtcppDevice * device = nirt::createDevice(
		video::EDT_OPENGL,
		core::dimension2du{1280, 720},
		32,
		false,
		true,
		true,
		nullptr
	);

	if (! device)
		throw std::runtime_error{"Can not create nirtcpp device!"};

	scene::ISceneManager * smgr = device->getSceneManager();
	video::IVideoDriver * driver = device->getVideoDriver();

	scene::ICameraSceneNode * camera = smgr->addCameraSceneNodeFPS(
		nullptr,	// parent node
		45.0,	// rotation speed
		0.5,	// movement speed
		-1,	// id
		nullptr,	// keymap array
		0,	// keymap array size
		false,	// disable vertical movement?
		5.0,	// jump speed
		false,	// invert mouse?
		true	// make active?
	);
	camera->setTarget(camera->getPosition() + core::vector3df{0,0,100});

	gui::ICursorControl * cursor_control = device->getCursorControl();
	cursor_control->setVisible(false);

	io::IFileSystem * nirtfs = device->getFileSystem();

	// If the filesystem failed to add, we continue.
	bool status = false;
	for (fs::path path: {"../../../media", "../../media", "../media", "./media", "."})
	{
		path /= "q3dm6ish.pk3";
		path.make_preferred();
		if (fs::exists(path))
		{
			status = nirtfs->addFileArchive(path.string().data());
			break;
		}
	}
	if (! status)
		std::cerr << "Can not add file archive to filesystem!\n";
	
	scene::IOctreeSceneNode * map = smgr->addOctreeSceneNode(
		smgr->getMesh("q3dm6ish.bsp"),
		nullptr,
		-1,
		32,
		false
	);
	if (! map)
		throw std::runtime_error{"Can not load map mesh!"};
	
	fs::path dir{"screenshots"};
	if (! fs::exists(dir) && ! fs::create_directory(dir))
		throw std::runtime_error{"Can not create "s + dir.string()};

	nirt::u32 id = 100000000;

	nirt::ITimer * timer = device->getTimer();
	nirt::u32 start = timer->getTime();
	const nirt::u32 end = start + 60'000;
	nirt::u32 now = start;
	nirt::u32 old = now;
	constexpr nirt::u32 delta = static_cast<nirt::u32>(1000.0/24);

	bool take = true;
	
	while (device->run())
	{
		if (device->isWindowActive())
		{
			driver->beginScene(
				video::ECBF_COLOR | video::ECBF_DEPTH,
				video::SColor{0xff3788aa}
			);
			smgr->drawAll();
			driver->endScene();

			if (take)
			{
				now = timer->getTime();
				if (now >= old + delta)
				{
					old = now;
					id++;
					fs::path file_path = dir / (std::to_string(id) + ".jpg");

					// IVideoDriver::createScreenShot(format=???, target=???)
					video::IImage * image = driver->createScreenShot();

					// IVideoDriver::writeImageToFile(image, file_or_filename, param=0)
					driver->writeImageToFile(image, file_path.string().data());

					// Be careful! The program will leak more and more memory without drop every image.
					image->drop();

					std::cout << "Saved: " << dir << "  |  "
						<< now*1.0/1000 << "  |  "
						<< end*1.0/1000
						<< std::endl;
				}
				if (now >= end)
				{
					device->closeDevice(); // close window!
				}
			}
		}
		else
		{
			device->yield();
		}
	}
}
catch (std::exception & err)
{
	std::cerr << "------------------------------------------------------------------------\n";
	std::cerr << err.what() << std::endl;
	return 1;
}

