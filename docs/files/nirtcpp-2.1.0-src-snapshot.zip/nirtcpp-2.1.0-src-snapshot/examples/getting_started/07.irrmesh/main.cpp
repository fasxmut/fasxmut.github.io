#include <nirtcpp/core.hpp>
#include <boost/assert.hpp>
#include <iostream>
#include "get_from_media_path.hpp"

int main(int argc, char ** argv)
{
	nirt::NirtcppDevice * device = nirt::createDevice(
		nirt::video::EDT_OPENGL,
		nirt::core::dimension2du{1280, 720},
		32,
		false,
		true,
		true,
		nullptr
	);
	BOOST_ASSERT(device != nullptr);
	nirt::video::IVideoDriver * driver = device->getVideoDriver();
	nirt::scene::ISceneManager * smgr = device->getSceneManager();

	nirt::scene::IAnimatedMesh * mesh = smgr->getMesh(get_from_media_path("ninja.b3d").data());

	nirt::scene::IAnimatedMeshSceneNode * node = smgr->addAnimatedMeshSceneNode(
		mesh,
		nullptr,
		-1,
		nirt::core::vector3df{0},
		nirt::core::vector3df{0},
		nirt::core::vector3df{1},
		false
	);
	std::string export_name = "./output.irrmesh";
	if (node)
	{
		node->setMaterialFlag(nirt::video::EMF_LIGHTING, false);
		std::cout << "Frame Count: " << mesh->getFrameCount() << std::endl;
		nirt::scene::IMesh * mesh0 = mesh->getMesh(0);

		nirt::io::IWriteFile * file = device->getFileSystem()->createAndWriteFile(export_name.data(), false);
		nirt::scene::IMeshWriter * writer = smgr->createMeshWriter(nirt::scene::EMWT_IRR_MESH);
		writer->writeMesh(file, mesh0, nirt::scene::EMWF_NONE);
		writer->drop();
		file->drop();
	}

	nirt::scene::IAnimatedMeshSceneNode * node2 = smgr->addAnimatedMeshSceneNode(
		smgr->getMesh(export_name.data()),
		nullptr,
		-1,
		{-10,0,0},
		{0,0,0},
		{1,1,1},
		false
	);
	if (node2)
		node2->setMaterialFlag(nirt::video::EMF_LIGHTING, false);
	
	nirt::scene::ICameraSceneNode * camera = smgr->addCameraSceneNodeFPS(
		nullptr, 35.0f, 0.02f, -1, nullptr, 0, false, 7.0f, false, true
	);
	camera->setPosition({15,2,-15});

	device->getCursorControl()->setVisible(false);

	while (device->run())
	{
		driver->beginScene(nirt::video::ECBF_COLOR | nirt::video::ECBF_DEPTH, nirt::video::SColor{0xff78a9f2});
		if (! device->isWindowActive())
			device->yield();
		smgr->drawAll();
		driver->endScene();
	}

	device->drop();
}

