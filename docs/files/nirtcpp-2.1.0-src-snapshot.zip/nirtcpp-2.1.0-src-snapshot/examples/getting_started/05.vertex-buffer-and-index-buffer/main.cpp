// Vertex Buffer and Index Buffer of Nirtcpp (Implemented by Irrlicht).
#include <nirtcpp/core.hpp>
#include <boost/assert.hpp>
#include <vector>

class vbo_ibo_object
{
private:
	std::vector<nirt::video::S3DVertex> vertices;
	std::vector<nirt::u16> indices;
	nirt::video::IVideoDriver * driver;
	nirt::video::SMaterial material;
public:
	vbo_ibo_object(
		const std::initializer_list<nirt::video::S3DVertex> & list_verts,
		const std::initializer_list<nirt::u16> & list_inds,
		nirt::video::IVideoDriver * driver,
		bool wireframe = false
	):
		vertices{list_verts},
		indices{list_inds},
		driver{driver}
	{
		material.Lighting = false;
		material.Wireframe = wireframe;
	}
	void draw()
	{
		driver->setMaterial(material);
		driver->drawVertexPrimitiveList(
			vertices.data(),
			vertices.size(),
			indices.data(),
			indices.size()/3,
			nirt::video::EVT_STANDARD,
			nirt::scene::EPT_TRIANGLES,
			nirt::video::EIT_16BIT
		);
	}
};

int main()
{
	nirt::NirtcppDevice * device = nirt::createDevice(
		nirt::video::EDT_OPENGL,
		nirt::core::dimension2du{1280, 720},
		32,
		false,
		true,
		true,
		nullptr
	);
	device->setWindowCaption(L"Vertex Buffer and Index Buffer Nirtcpp");
	BOOST_ASSERT(device != nullptr);
	nirt::video::IVideoDriver * driver = device->getVideoDriver();
	nirt::scene::ISceneManager * smgr = device->getSceneManager();
	nirt::gui::IGUIEnvironment * ngui = device->getGUIEnvironment();

	vbo_ibo_object cube{
		{
			{10,10,-10, 1,1,-1, {0xffff0000}, 0,0},		// 0
			{10,10,10, 1,1,1, {0xff00ff00}, 0,0},		// 1
			{-10,10,10, -1,1,1, {0xff0000ff}, 0,0},		// 2
			{-10,10,-10, -1,1,-1, {0xff00ff00}, 0,0},		// 3

			{10,-10,-10, 1,-1,-1, {0xff0000ff}, 0,0},		// 4
			{10,-10,10, 1,-1,1, {0xffff0000}, 0,0},		// 5
			{-10,-10,10, -1,-1,1, {0xff00ff00}, 0,0},		// 6
			{-10,-10,-10, -1,-1,-1, {0xff0000ff}, 0,0}		// 7
		},
		{
			2,1,0, 3,2,0,		// top
			3,0,4, 7,3,4,		// front
			0,1,5, 5,4,0,		// right
			4,5,6, 6,7,4,		// bottom
			1,2,5, 2,6,5,		// back
			2,3,7, 7,6,2		// left
		},
		driver
	};

	nirt::scene::ICameraSceneNode * camera = smgr->addCameraSceneNodeFPS(
		nullptr, 35.0f, 0.02f, -1, nullptr, 0, false, 5.0f, false, true
	);

	camera->setPosition(nirt::core::vector3df{15, 15, -45});
	camera->setTarget(nirt::core::vector3df{0,-15,0});

	device->getCursorControl()->setVisible(false);

	while (device->run())
	{
		if (device->isWindowActive())
		{
			driver->beginScene(nirt::video::ECBF_COLOR | nirt::video::ECBF_DEPTH, nirt::video::SColor{0xff4789ab});
			smgr->drawAll();
			ngui->drawAll();
			cube.draw();
			driver->endScene();
		}
		else
		{
			device->yield();
		}
	}
	device->drop();
}

