#include <nirtcpp/core.hpp>
#include <vector>
#include <iostream>
#include <boost/assert.hpp>

class face_node: public nirt::scene::ISceneNode
{
private:
	const std::vector<nirt::video::S3DVertex> face_vertices;
	const std::vector<nirt::u16> face_indices;
	nirt::video::IVideoDriver * driver;
	nirt::video::SMaterial material;
public:
	face_node(
		nirt::scene::ISceneNode * parent_node,
		nirt::s32 id,
		nirt::scene::ISceneManager * smgr
	):
		nirt::scene::ISceneNode{parent_node?parent_node:smgr->getRootSceneNode(), smgr, id},
		face_vertices {
			{0,-5,0,		0,0,-1,		{0xff000000},		0.5,0.95},		// 0
			{5,0,0,		0,0,-1,		{0xff00ff00},		0.8,0.8},		// 1
			{0,0,-2,		0,0,-1,		{0xff00ff00},		0.5,0.75},		// 2
			{-5,0,0,		0,0,-1,		{0xff00ff00},		0.2,0.8},		// 3
			{0,5,-3,		0,0,-1,		{0xff00ffff},		0.5,0.5},		// 4
			{8,12,0,		0,0,-1,		{0xff0000ff},		0.85,0.1},		// 5
			{0,10,-4,		0,0,-1,		{0xffff0000},		0.5,0.25},		// 6
			{-8,12,0,		0,0,-1,		{0xff0000ff},		0.15,0.1},		// 7
			{0,15,0,		0,0,-1,		{0xffff00ff},		0.5,0}		// 8
		},
		face_indices{
			3,2,0,
			0,2,1,
			3,4,2,
			2,4,1,
			3,7,4,
			4,5,1,
			4,7,6,
			4,6,5,
			6,7,8,
			6,8,5
		}
	{
		driver = this->SceneManager->getVideoDriver();
		//material.Wireframe = false;
		//material.Lighting = false;
	}
	void OnRegisterSceneNode() override
	{
		if (this->IsVisible)
			this->SceneManager->registerNodeForRendering(this);
		nirt::scene::ISceneNode::OnRegisterSceneNode();
	}
	void render() override
	{
		driver->setMaterial(material);
		driver->drawVertexPrimitiveList(
			face_vertices.data(),
			face_vertices.size(),
			face_indices.data(),
			face_indices.size()/3,
			nirt::video::EVT_STANDARD,
			nirt::scene::EPT_TRIANGLES,
			nirt::video::EIT_16BIT
		);
	}
	void setMaterialTexture(nirt::u32 tex_layer, nirt::video::ITexture * tex)
	{
		material.setTexture(tex_layer, tex);
		nirt::scene::ISceneNode::setMaterialTexture(tex_layer, tex);
	}
	void setMaterialFlag(nirt::video::E_MATERIAL_FLAG flag, bool value)
	{
		material.setFlag(flag, value);
		nirt::scene::ISceneNode::setMaterialFlag(flag, value);
	}
	const nirt::core::aabbox3df & getBoundingBox() const override
	{
		return {};
	}
};

int main()
{
	nirt::NirtcppDevice * device = nirt::createDevice(
		nirt::video::EDT_OPENGL,
		nirt::core::dimension2du{1280, 720},
		32,
		false,
		true,
		true,
		nullptr
	);
	BOOST_ASSERT(device != nullptr);
	nirt::scene::ISceneManager * smgr = device->getSceneManager();
	nirt::video::IVideoDriver * driver = device->getVideoDriver();

	face_node * face = new face_node{nullptr, -1, smgr};
	BOOST_ASSERT(face != nullptr);
	face->setMaterialTexture(0, driver->getTexture("face.png"));
	face->setMaterialFlag(nirt::video::EMF_LIGHTING, false);
	face->drop();

	nirt::scene::ICameraSceneNode * camera = smgr->addCameraSceneNodeFPS(
		nullptr, 35.0f, 0.02f, -1, nullptr, 0, false, 7.0f, false, true
	);
	camera->setPosition({0, 10, -25});
	camera->setTarget({0,0,0});

	device->getCursorControl()->setVisible(false);

	while (device->run())
	{
		driver->beginScene(true, true, nirt::video::SColor{0xff37789a});
		smgr->drawAll();
		driver->endScene();
	}

	device->drop();
}

