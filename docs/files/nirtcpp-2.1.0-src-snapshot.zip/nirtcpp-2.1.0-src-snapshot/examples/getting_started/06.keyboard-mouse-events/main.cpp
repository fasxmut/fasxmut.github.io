/*
Events:
	Key L: turn on/off lighting.
	Key Q: Quit
	L-Mouse Click: move model right.
	R-Mouse Click: move model left.
*/

#include <nirtcpp/core.hpp>
#include <boost/assert.hpp>
#include <filesystem>

namespace stdfs = std::filesystem;

class km_event: public nirt::IEventReceiver
{
private:
	nirt::NirtcppDevice * device;
	nirt::scene::ISceneNode * node;
	bool lighting = false;
public:
	km_event(nirt::NirtcppDevice * __device, nirt::scene::ISceneNode * __node):
		device{__device},
		node{__node}
	{
	}
	bool OnEvent(const nirt::SEvent & event) override
	{
		switch (event.EventType)
		{
		case nirt::EET_KEY_INPUT_EVENT:
			switch (event.KeyInput.Key)
			{
			case nirt::KEY_KEY_L:
				if (! event.KeyInput.PressedDown)
				{
					this->lighting = ! this->lighting;
					node->setMaterialFlag(nirt::video::EMF_LIGHTING, this->lighting);
				}
				break;
			case nirt::KEY_KEY_Q:
				device->closeDevice();
				break;
			default:
				break;
			}
			break;
		case nirt::EET_MOUSE_INPUT_EVENT:
			switch (event.MouseInput.Event)
			{
			case nirt::EMIE_LMOUSE_LEFT_UP:
				node->setPosition(node->getPosition()+nirt::core::vector3df{-10,0,0});
				break;
			case nirt::EMIE_RMOUSE_LEFT_UP:
				node->setPosition(node->getPosition()+nirt::core::vector3df{10,0,0});
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		return false;
	}
};

int main()
{
	nirt::NirtcppDevice * device = nirt::createDevice(nirt::video::EDT_OPENGL, nirt::core::dimension2du{1280, 720});
	BOOST_ASSERT(device != nullptr);
	nirt::scene::ISceneManager * smgr = device->getSceneManager();
	nirt::video::IVideoDriver * driver = device->getVideoDriver();

	nirt::scene::ICameraSceneNode * camera = smgr->addCameraSceneNodeFPS(
		nullptr, 35.0f, 0.02f, -1, nullptr, 0, false, 10.0f, false, true
	);
	camera->setPosition({10,10,15});
	camera->setTarget({0,0,0});
	device->getCursorControl()->setVisible(false);

	auto find_ninja = [] -> std::string
	{
		for (stdfs::path path: {".", "./media", "../media", "../../media", "../../../media", "../../../../media"})
		{
			path /= "ninja.b3d";
			if (stdfs::exists(path))
			{
				path.make_preferred();
				return path.string();
			}
		}
		return "";
	};

	nirt::scene::IAnimatedMeshSceneNode * ninja = smgr->addAnimatedMeshSceneNode(
		smgr->getMesh(find_ninja().data()),
		nullptr,
		-1,
		{0,0,0},
		{0,0,0},
		{1,1,1},
		false
	);
	if (ninja)
		ninja->setMaterialFlag(nirt::video::EMF_LIGHTING, false);

	km_event evt{device, ninja};
	device->setEventReceiver(&evt);

	while (device->run())
	{
		if (device->isWindowActive())
		{
			driver->beginScene(true, true, nirt::video::SColor{0xff37569a});
			smgr->drawAll();
			driver->endScene();
		}
		else
		{
			device->yield();
		}
	}
	device->drop();
}

