Examples Layout:
========================================================================

I. Take you to create a playable rendering world step by step.
------------------------------------------------------------------------
./getting_started/
	01.hello_world	-	How to load a mesh model.
	02.display_quake3_map	-	How to load a quake3 bsp map as world map.
	03.collision_detection	-	How to create collision detection between nodes.

II. Advanced nirtcpp skills.
------------------------------------------------------------------------
./quake3_engine/
	quake3_map_shader	-	Get shader from quake3 map, and create node with the shader.



