#ifndef __nirtcpp_example_test_get_from_media_path__
#define __nirtcpp_example_test_get_from_media_path__

#include <filesystem>
#include <string>
#include <string_view>

auto get_from_media_path = [] (const std::string & filename) -> std::string
{
	namespace fs = std::filesystem;
	for (fs::path path: {".", "./media", "../media", "../../media", "../../../media", "../../../../media", "../../../../../media"})
	{
		path /= filename;
		if (fs::exists(path))
		{
			path.make_preferred();
			return path.string();
		}
	}
	return "";
};

#endif

